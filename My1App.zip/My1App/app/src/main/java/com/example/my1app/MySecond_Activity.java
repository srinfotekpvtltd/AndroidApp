package com.example.my1app;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MySecond_Activity extends AppCompatActivity {

    Button btnLogin;
    EditText txtUsernme,txtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_second);

        btnLogin= findViewById(R.id.btnLogin);
        txtPassword=(EditText) findViewById(R.id.txtPassword);
        txtUsernme=(EditText) findViewById(R.id.txtUsername);


    }
}