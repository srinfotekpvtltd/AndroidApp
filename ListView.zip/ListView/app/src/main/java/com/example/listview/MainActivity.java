package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView LVCitys;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LVCitys=findViewById(R.id.LVCiys);

        ArrayList<String> citysArryList=new ArrayList<String>();
        citysArryList.add("Mumbai");
        citysArryList.add("Pune");
        citysArryList.add("Nagpur");
        citysArryList.add("Thane");
        citysArryList.add("PCMC, Pune");
        citysArryList.add("Nashik");
        citysArryList.add("Kalyan-Dombivli");
        citysArryList.add("Vasai-Virar City MC");
        citysArryList.add("Aurangabad");
        citysArryList.add("Navi Mumbai");
        citysArryList.add("Solapur");
        citysArryList.add("Mira-Bhayandar");
        citysArryList.add("Bhiwandi-Nizampur MC");
        citysArryList.add("Jalgaon");
        citysArryList.add("Amravati");
        citysArryList.add("Nanded");
        citysArryList.add("Kolhapur");
        citysArryList.add("Ulhasnagar");
        citysArryList.add("Sangli-Miraj-Kupwad");
        citysArryList.add("Malegaon");
        citysArryList.add("Akola");
        citysArryList.add("Latur");
        citysArryList.add("Dhule");
        citysArryList.add("Ahmednagar");
        citysArryList.add("Chandrapur");
        citysArryList.add("Parbhani");
        citysArryList.add("Ichalkaranji");
        citysArryList.add("Jalna");
        citysArryList.add("Ambarnath");
        citysArryList.add("Bhusawal");
        citysArryList.add("Panvel");
        citysArryList.add("Badlapur");
        citysArryList.add("Beed");
        citysArryList.add("Gondia");
        citysArryList.add("Satara");
        citysArryList.add("Barshi");
        citysArryList.add("Yavatmal");
        citysArryList.add("Achalpur");
        citysArryList.add("Osmanabad");
        citysArryList.add("Nandurbar");
        citysArryList.add("Wardha");
        citysArryList.add("Udgir");
        citysArryList.add("Hinganghat");

        ArrayAdapter<String> cityArrayAdaper=new ArrayAdapter<String>(
          this,R.layout.simple_lt_for_listview,citysArryList
        );

        LVCitys.setAdapter(cityArrayAdaper);

    }
}